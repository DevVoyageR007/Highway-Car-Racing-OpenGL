// Highway Car Racing Game - Hard Mode (No Rocks)
// Language: C++
// Use this file as main.cpp

#include <windows.h>        // For Windows; if Linux/Mac, you can remove this line
#include <GL/glut.h>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <string>
#include <cmath>

// ---------- Window settings ----------
int winWidth  = 800;
int winHeight = 600;

// ---------- Game states ----------
const int STATE_MENU     = 0;
const int STATE_PLAYING  = 1;
const int STATE_GAMEOVER = 2;
int gameState = STATE_MENU;

// ---------- Player (main car) ----------
float carX;
float carY = 80.0f;
float carW = 70.0f;
float carH = 120.0f;
float carSpeed = 10.0f;
int   lives = 3;

// Banking (tilt) effect
float carTiltAngle  = 0.0f;
float carTiltTarget = 0.0f;

// ---------- Enemy cars ----------
struct EnemyCar {
    float x, y;
    float w, h;
    float speed;
    float r, g, b;
    bool  active;
    bool  scored;          // cross korle score add hoye geche kina

    // side movement for hard mode
    bool  canSideMove;
    float sideSpeed;
    int   sideDir;         // -1, 0, +1
    float sideChangeTimer; // frame counter
};
std::vector<EnemyCar> enemies;

// ---------- Buildings ----------
struct Building {
    float x, y;
    float w, h;
    bool  onLeft;          // left side or right side (3D side drawing er jonno)
};
std::vector<Building> buildings;

// ---------- Score & timing ----------
int score = 0;
int bestScore = 0;

int enemySpawnCounter  = 0;
int enemySpawnInterval = 45;   // shuru te slow
int enemySpawnMin      = 18;
int frameCount         = 0;

// ---------- Keyboard state ----------
bool keyMoveLeft  = false;
bool keyMoveRight = false;

// ---------- Road / background scroll ----------
float laneOffset = 0.0f;      // dashed line er scroll
float roadScrollSpeed = 6.0f;

// ---------- Utility ----------
float frand(float a, float b) {
    return a + (b - a) * (rand() / (float)RAND_MAX);
}

// ---------- Draw text ----------
void drawString(float x, float y, const std::string &str,
                void *font = GLUT_BITMAP_HELVETICA_18) {
    glRasterPos2f(x, y);
    for (size_t i = 0; i < str.size(); ++i) {
        glutBitmapCharacter(font, str[i]);
    }
}

// ---------- Player Car (3D-ish top view + headlight beams) ----------
void drawPlayerCar() {
    float centerX = carX + carW / 2.0f;
    float centerY = carY + carH / 2.0f;

    glPushMatrix();

    // Tilt (rotate) around center
    glTranslatef(centerX, centerY, 0.0f);
    glRotatef(carTiltAngle, 0.0f, 0.0f, 1.0f);
    glTranslatef(-centerX, -centerY, 0.0f);

    // Shadow under car
    glColor4f(0.0f, 0.0f, 0.0f, 0.30f);
    glBegin(GL_TRIANGLE_FAN);
        glVertex2f(centerX, carY - 10.0f);
        int segShadow = 30;
        float rShadowX = carW * 0.9f;
        float rShadowY = carH * 0.4f;
        for (int i = 0; i <= segShadow; ++i) {
            float a = (float)i / segShadow * 3.14159f * 2.0f;
            float x = centerX + cosf(a) * rShadowX * 0.6f;
            float y = carY - 10.0f + sinf(a) * rShadowY * 0.6f;
            glColor4f(0.0f, 0.0f, 0.0f, 0.02f);
            glVertex2f(x, y);
        }
    glEnd();

    // Main body gradient (bottom dark, top light)
    glBegin(GL_QUADS);
        glColor3f(0.09f, 0.10f, 0.18f);
        glVertex2f(carX,       carY);
        glVertex2f(carX + carW,carY);
        glColor3f(0.25f, 0.28f, 0.40f);
        glVertex2f(carX + carW,carY + carH);
        glVertex2f(carX,       carY + carH);
    glEnd();

    // Center sport stripe
    glBegin(GL_QUADS);
        glColor3f(0.85f, 0.10f, 0.15f);
        glVertex2f(centerX - carW * 0.15f, carY + carH * 0.05f);
        glVertex2f(centerX + carW * 0.15f, carY + carH * 0.05f);
        glColor3f(1.0f,   0.30f, 0.30f);
        glVertex2f(centerX + carW * 0.10f, carY + carH * 0.95f);
        glVertex2f(centerX - carW * 0.10f, carY + carH * 0.95f);
    glEnd();

    // Roof / cockpit (glassy)
    glBegin(GL_QUADS);
        glColor3f(0.05f, 0.55f, 0.85f);
        glVertex2f(centerX - carW * 0.20f, carY + carH * 0.30f);
        glVertex2f(centerX + carW * 0.20f, carY + carH * 0.30f);
        glColor3f(0.12f, 0.75f, 1.0f);
        glVertex2f(centerX + carW * 0.18f, carY + carH * 0.75f);
        glVertex2f(centerX - carW * 0.18f, carY + carH * 0.75f);
    glEnd();

    // Roof highlight
    glLineWidth(2.0f);
    glColor3f(0.9f, 1.0f, 1.0f);
    glBegin(GL_LINES);
        glVertex2f(centerX - carW * 0.08f, carY + carH * 0.35f);
        glVertex2f(centerX - carW * 0.02f, carY + carH * 0.70f);
    glEnd();
    glLineWidth(1.0f);

    // Wheels (dark gray)
    float wheelW = carW * 0.20f;
    float wheelH = carH * 0.25f;

    glColor3f(0.05f, 0.05f, 0.05f);
    // front-left
    glBegin(GL_QUADS);
        glVertex2f(carX - wheelW * 0.8f, carY + carH * 0.15f);
        glVertex2f(carX,                  carY + carH * 0.15f);
        glVertex2f(carX,                  carY + carH * 0.15f + wheelH);
        glVertex2f(carX - wheelW * 0.8f, carY + carH * 0.15f + wheelH);
    glEnd();
    // front-right
    glBegin(GL_QUADS);
        glVertex2f(carX + carW,              carY + carH * 0.15f);
        glVertex2f(carX + carW + wheelW*0.8f,carY + carH * 0.15f);
        glVertex2f(carX + carW + wheelW*0.8f,carY + carH * 0.15f + wheelH);
        glVertex2f(carX + carW,              carY + carH * 0.15f + wheelH);
    glEnd();
    // rear-left
    glBegin(GL_QUADS);
        glVertex2f(carX - wheelW * 0.8f, carY + carH * 0.65f);
        glVertex2f(carX,                  carY + carH * 0.65f);
        glVertex2f(carX,                  carY + carH * 0.65f + wheelH);
        glVertex2f(carX - wheelW * 0.8f, carY + carH * 0.65f + wheelH);
    glEnd();
    // rear-right
    glBegin(GL_QUADS);
        glVertex2f(carX + carW,              carY + carH * 0.65f);
        glVertex2f(carX + carW + wheelW*0.8f,carY + carH * 0.65f);
        glVertex2f(carX + carW + wheelW*0.8f,carY + carH * 0.65f + wheelH);
        glVertex2f(carX + carW,              carY + carH * 0.65f + wheelH);
    glEnd();

    // ---- Headlights (3D-ish) ----
    float frontY = carY + carH;
    float leftHeadX  = carX + carW * 0.22f;
    float rightHeadX = carX + carW * 0.78f;

    // Headlight housing
    glBegin(GL_QUADS);
        glColor3f(0.35f, 0.35f, 0.40f);
        glVertex2f(leftHeadX - 6, frontY - 6);
        glVertex2f(leftHeadX + 6, frontY - 6);
        glColor3f(0.10f, 0.10f, 0.12f);
        glVertex2f(leftHeadX + 6, frontY + 4);
        glVertex2f(leftHeadX - 6, frontY + 4);

        glColor3f(0.35f, 0.35f, 0.40f);
        glVertex2f(rightHeadX - 6, frontY - 6);
        glVertex2f(rightHeadX + 6, frontY - 6);
        glColor3f(0.10f, 0.10f, 0.12f);
        glVertex2f(rightHeadX + 6, frontY + 4);
        glVertex2f(rightHeadX - 6, frontY + 4);
    glEnd();

    // Light bulbs
    glBegin(GL_QUADS);
        glColor3f(1.0f, 1.0f, 0.8f);
        glVertex2f(leftHeadX - 4, frontY - 3);
        glVertex2f(leftHeadX + 4, frontY - 3);
        glColor3f(1.0f, 0.95f, 0.4f);
        glVertex2f(leftHeadX + 4, frontY + 3);
        glVertex2f(leftHeadX - 4, frontY + 3);

        glColor3f(1.0f, 1.0f, 0.8f);
        glVertex2f(rightHeadX - 4, frontY - 3);
        glVertex2f(rightHeadX + 4, frontY - 3);
        glColor3f(1.0f, 0.95f, 0.4f);
        glVertex2f(rightHeadX + 4, frontY + 3);
        glVertex2f(rightHeadX - 4, frontY + 3);
    glEnd();

    // ---- Headlight beams on road (soft cones) ----
    float beamLen    = 220.0f;   // forward distance
    float beamSpread = 80.0f;    // width

    glBegin(GL_TRIANGLE_FAN);
        glColor4f(1.0f, 1.0f, 0.9f, 0.40f);
        glVertex2f(leftHeadX, frontY + 4);
        glColor4f(1.0f, 1.0f, 0.7f, 0.00f);
        glVertex2f(leftHeadX - beamSpread * 0.4f, frontY + beamLen);
        glVertex2f(leftHeadX + beamSpread * 0.4f, frontY + beamLen);
    glEnd();

    glBegin(GL_TRIANGLE_FAN);
        glColor4f(1.0f, 1.0f, 0.9f, 0.40f);
        glVertex2f(rightHeadX, frontY + 4);
        glColor4f(1.0f, 1.0f, 0.7f, 0.00f);
        glVertex2f(rightHeadX - beamSpread * 0.4f, frontY + beamLen);
        glVertex2f(rightHeadX + beamSpread * 0.4f, frontY + beamLen);
    glEnd();

    glPopMatrix();
}

// ---------- Enemy car (simpler, different design) ----------
void drawEnemyCar(const EnemyCar &e) {
    float cx = e.x + e.w / 2.0f;
    float cy = e.y + e.h / 2.0f;

    glPushMatrix();

    glTranslatef(cx, cy, 0.0f);
    glTranslatef(-cx, -cy, 0.0f);

    // Body
    glBegin(GL_QUADS);
        glColor3f(e.r * 0.6f, e.g * 0.6f, e.b * 0.6f);
        glVertex2f(e.x,       e.y);
        glVertex2f(e.x + e.w, e.y);
        glColor3f(e.r, e.g, e.b);
        glVertex2f(e.x + e.w, e.y + e.h);
        glVertex2f(e.x,       e.y + e.h);
    glEnd();

    // Roof
    glBegin(GL_QUADS);
        glColor3f(0.2f, 0.2f, 0.25f);
        glVertex2f(e.x + e.w * 0.15f, e.y + e.h * 0.25f);
        glVertex2f(e.x + e.w * 0.85f, e.y + e.h * 0.25f);
        glColor3f(0.4f, 0.4f, 0.45f);
        glVertex2f(e.x + e.w * 0.80f, e.y + e.h * 0.75f);
        glVertex2f(e.x + e.w * 0.20f, e.y + e.h * 0.75f);
    glEnd();

    // Wheels
    glColor3f(0.05f, 0.05f, 0.05f);
    float wheelH = e.h * 0.20f;
    glBegin(GL_QUADS);
        glVertex2f(e.x - e.w*0.15f, e.y + e.h * 0.15f);
        glVertex2f(e.x,             e.y + e.h * 0.15f);
        glVertex2f(e.x,             e.y + e.h * 0.15f + wheelH);
        glVertex2f(e.x - e.w*0.15f, e.y + e.h * 0.15f + wheelH);

        glVertex2f(e.x + e.w,             e.y + e.h * 0.15f);
        glVertex2f(e.x + e.w + e.w*0.15f, e.y + e.h * 0.15f);
        glVertex2f(e.x + e.w + e.w*0.15f, e.y + e.h * 0.15f + wheelH);
        glVertex2f(e.x + e.w,             e.y + e.h * 0.15f + wheelH);
    glEnd();

    glPopMatrix();
}

// ---------- AABB collision ----------
bool rectIntersect(float x1, float y1, float w1, float h1,
                   float x2, float y2, float w2, float h2) {
    if (x1 + w1 < x2) return false;
    if (x2 + w2 < x1) return false;
    if (y1 + h1 < y2) return false;
    if (y2 + h2 < y1) return false;
    return true;
}

// ---------- Init buildings ----------
void initBuildings() {
    buildings.clear();

    float roadX  = winWidth * 0.25f;
    float roadW  = winWidth * 0.50f;

    // Left side: 3 buildings
    for (int i = 0; i < 3; ++i) {
        Building b;
        b.onLeft = true;
        b.w = 90.0f;
        b.h = frand(130.0f, 220.0f);
        b.x = roadX - b.w - 40.0f;
        b.y = frand(0.0f, (float)winHeight * 1.5f);
        buildings.push_back(b);
    }

    // Right side: 2 buildings
    for (int i = 0; i < 2; ++i) {
        Building b;
        b.onLeft = false;
        b.w = 90.0f;
        b.h = frand(130.0f, 220.0f);
        b.x = roadX + roadW + 40.0f;
        b.y = frand(0.0f, (float)winHeight * 1.5f);
        buildings.push_back(b);
    }
}

// ---------- Draw one building (3D-ish) ----------
void drawBuilding(const Building &b) {
    float frontX = b.x;
    float frontY = b.y;
    float w = b.w;
    float h = b.h;

    // side depth (towards road)
    float depth = b.onLeft ? 18.0f : -18.0f;

    // FRONT face
    glColor3f(0.18f, 0.18f, 0.24f);
    glBegin(GL_QUADS);
        glVertex2f(frontX,       frontY);
        glVertex2f(frontX + w,   frontY);
        glVertex2f(frontX + w,   frontY + h);
        glVertex2f(frontX,       frontY + h);
    glEnd();

    // SIDE face (towards road)
    if (b.onLeft) {
        // right side visible
        glColor3f(0.10f, 0.10f, 0.16f);
        glBegin(GL_QUADS);
            glVertex2f(frontX + w,         frontY);
            glVertex2f(frontX + w + depth, frontY + 8);
            glVertex2f(frontX + w + depth, frontY + h + 10);
            glVertex2f(frontX + w,         frontY + h);
        glEnd();
    } else {
        // left side visible
        glColor3f(0.10f, 0.10f, 0.16f);
        glBegin(GL_QUADS);
            glVertex2f(frontX,         frontY);
            glVertex2f(frontX + depth, frontY + 8);
            glVertex2f(frontX + depth, frontY + h + 10);
            glVertex2f(frontX,         frontY + h);
        glEnd();
    }

    // ROOF (top plate 3D)
    glColor3f(0.25f, 0.25f, 0.32f);
    glBegin(GL_POLYGON);
        if (b.onLeft) {
            glVertex2f(frontX,         frontY + h);
            glVertex2f(frontX + w,     frontY + h);
            glVertex2f(frontX + w + depth, frontY + h + 10);
            glVertex2f(frontX + depth,     frontY + h + 10);
        } else {
            glVertex2f(frontX,         frontY + h);
            glVertex2f(frontX + w,     frontY + h);
            glVertex2f(frontX + depth + w, frontY + h + 10);
            glVertex2f(frontX + depth,     frontY + h + 10);
        }
    glEnd();

    // front windows
    glColor3f(0.9f, 0.85f, 0.4f);
    float wx = frontX + 10;
    float wy = frontY + 15;
    float wsx = 12;
    float wsy = 18;
    for (int r = 0; r < 5; ++r) {
        for (int c = 0; c < 3; ++c) {
            glBegin(GL_QUADS);
                glVertex2f(wx + c*20,       wy + r*25);
                glVertex2f(wx + c*20 + wsx, wy + r*25);
                glVertex2f(wx + c*20 + wsx, wy + r*25 + wsy);
                glVertex2f(wx + c*20,       wy + r*25 + wsy);
            glEnd();
        }
    }

    // side vertical lights (just a few strips)
    glColor3f(0.75f, 0.70f, 0.35f);
    if (b.onLeft) {
        float sx = frontX + w + depth * 0.6f;
        for (int i = 0; i < 3; ++i) {
            glBegin(GL_QUADS);
                glVertex2f(sx + i*3, frontY + 12);
                glVertex2f(sx + i*3 + 2, frontY + 12);
                glVertex2f(sx + i*3 + 2, frontY + h);
                glVertex2f(sx + i*3,     frontY + h);
            glEnd();
        }
    } else {
        float sx = frontX + depth * 0.6f;
        for (int i = 0; i < 3; ++i) {
            glBegin(GL_QUADS);
                glVertex2f(sx - i*3, frontY + 12);
                glVertex2f(sx - i*3 + 2, frontY + 12);
                glVertex2f(sx - i*3 + 2, frontY + h);
                glVertex2f(sx - i*3,     frontY + h);
            glEnd();
        }
    }
}

// ---------- Draw background: road + buildings ----------
void drawBackground() {
    // Sky gradient
    glBegin(GL_QUADS);
        glColor3f(0.05f, 0.08f, 0.15f);
        glVertex2f(0,         winHeight);
        glVertex2f(winWidth,  winHeight);
        glColor3f(0.10f, 0.12f, 0.20f);
        glVertex2f(winWidth,  winHeight * 0.55f);
        glVertex2f(0,         winHeight * 0.55f);
    glEnd();

    // Ground (sides)
    glBegin(GL_QUADS);
        glColor3f(0.15f, 0.25f, 0.11f);
        glVertex2f(0, 0);
        glVertex2f(winWidth, 0);
        glColor3f(0.06f, 0.09f, 0.05f);
        glVertex2f(winWidth, winHeight * 0.55f);
        glVertex2f(0,        winHeight * 0.55f);
    glEnd();

    // Road in middle
    float roadX  = winWidth * 0.25f;
    float roadW  = winWidth * 0.50f;

    glBegin(GL_QUADS);
        glColor3f(0.08f, 0.08f, 0.10f);
        glVertex2f(roadX,        0);
        glVertex2f(roadX + roadW,0);
        glColor3f(0.03f, 0.03f, 0.04f);
        glVertex2f(roadX + roadW,winHeight);
        glVertex2f(roadX,        winHeight);
    glEnd();

    // Road borders
    glLineWidth(4.0f);
    glColor3f(0.85f, 0.85f, 0.85f);
    glBegin(GL_LINES);
        glVertex2f(roadX,        0);
        glVertex2f(roadX,        winHeight);
        glVertex2f(roadX+roadW,  0);
        glVertex2f(roadX+roadW,  winHeight);
    glEnd();
    glLineWidth(1.0f);

    // Lane markers (3 lanes: 2 dashed lines)
    float lane1X = roadX + roadW / 3.0f;
    float lane2X = roadX + roadW * 2.0f / 3.0f;

    float dashLen  = 40.0f;
    float dashGap  = 80.0f;

    for (float y = -dashLen; y < winHeight + dashLen; y += dashGap) {
        float yy = y + laneOffset;
        // left dashed line
        glColor3f(0.95f, 0.95f, 0.90f);
        glBegin(GL_QUADS);
            glVertex2f(lane1X - 3, yy);
            glVertex2f(lane1X + 3, yy);
            glVertex2f(lane1X + 3, yy + dashLen);
            glVertex2f(lane1X - 3, yy + dashLen);
        glEnd();

        // right dashed line
        glBegin(GL_QUADS);
            glVertex2f(lane2X - 3, yy);
            glVertex2f(lane2X + 3, yy);
            glVertex2f(lane2X + 3, yy + dashLen);
            glVertex2f(lane2X - 3, yy + dashLen);
        glEnd();
    }

    // Buildings (moving down for forward feel)
    for (size_t i = 0; i < buildings.size(); ++i) {
        drawBuilding(buildings[i]);
    }
}

// ---------- Spawn enemy car ----------
void spawnEnemyCar() {
    float roadX  = winWidth * 0.25f;
    float roadW  = winWidth * 0.50f;

    // lane centers
    float laneCenters[3] = {
        roadX + roadW * 0.17f,
        roadX + roadW * 0.50f,
        roadX + roadW * 0.83f
    };

    EnemyCar e;
    e.w = 60.0f;
    e.h = 110.0f;
    int laneIndex = rand() % 3;
    e.x = laneCenters[laneIndex] - e.w / 2.0f;
    e.y = (float)winHeight + e.h + frand(10.0f, 120.0f);
    e.speed = frand(5.0f, 9.0f);
    e.active = true;
    e.scored = false;

    // random nice color
    float colors[6][3] = {
        {0.90f, 0.15f, 0.15f},
        {0.12f, 0.62f, 0.92f},
        {0.15f, 0.80f, 0.35f},
        {0.95f, 0.70f, 0.15f},
        {0.75f, 0.25f, 0.80f},
        {0.90f, 0.30f, 0.30f}
    };
    int c = rand() % 6;
    e.r = colors[c][0];
    e.g = colors[c][1];
    e.b = colors[c][2];

    // Side movement hard mode (approx 1/3 cars will move sideways)
    e.canSideMove = (rand() % 3 == 0);
    e.sideSpeed   = frand(1.5f, 3.0f);
    e.sideDir     = (rand() % 2 == 0 ? -1 : 1);
    e.sideChangeTimer = (float)(rand() % 90 + 40);

    enemies.push_back(e);
}

// ---------- Reset game ----------
void resetGame() {
    enemies.clear();
    score = 0;
    lives = 3;
    frameCount = 0;
    enemySpawnCounter  = 0;
    enemySpawnInterval = 45;

    carTiltAngle  = 0.0f;
    carTiltTarget = 0.0f;

    carX = winWidth / 2.0f - carW / 2.0f;
    carY = 80.0f;

    laneOffset = 0.0f;

    initBuildings();
}

// ---------- Display ----------
void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    drawBackground();

    if (gameState == STATE_MENU) {
        glColor3f(1.0f, 1.0f, 0.8f);
        drawString(winWidth / 2 - 210, winHeight / 2 + 80,
                   "HIGHWAY CAR RACING GAME - HARD MODE");

        glColor3f(1.0f, 1.0f, 1.0f);
        drawString(winWidth / 2 - 260, winHeight / 2 + 30,
                   "Use LEFT / RIGHT (or A / D) to move your car");
        drawString(winWidth / 2 - 260, winHeight / 2,
                   "Avoid traffic cars on the road!");
        drawString(winWidth / 2 - 260, winHeight / 2 - 30,
                   "Cross (overtake) cars to earn +10 points");

        glColor3f(0.5f, 1.0f, 0.5f);
        drawString(winWidth / 2 - 150, winHeight / 2 - 80,
                   "Press ENTER to START");
        drawString(winWidth / 2 - 150, winHeight / 2 - 110,
                   "Press ESC to EXIT");
    }
    else if (gameState == STATE_PLAYING) {
        // Draw enemies
        for (size_t i = 0; i < enemies.size(); ++i)
            if (enemies[i].active) drawEnemyCar(enemies[i]);

        // Draw player LAST (upor e thakbe)
        drawPlayerCar();

        // HUD
        glColor3f(1.0f, 1.0f, 1.0f);
        drawString(10, winHeight - 30, "Score: " + std::to_string(score));
        drawString(10, winHeight - 55, "Lives: " + std::to_string(lives));
    }
    else if (gameState == STATE_GAMEOVER) {
        glColor3f(1.0f, 0.5f, 0.5f);
        drawString(winWidth / 2 - 80, winHeight / 2 + 40, "GAME OVER");

        glColor3f(1.0f, 1.0f, 1.0f);
        drawString(winWidth / 2 - 70, winHeight / 2,
                   "Score: " + std::to_string(score));
        drawString(winWidth / 2 - 90, winHeight / 2 - 30,
                   "Best Score: " + std::to_string(bestScore));

        glColor3f(0.5f, 1.0f, 0.5f);
        drawString(winWidth / 2 - 160, winHeight / 2 - 80,
                   "Press ENTER to PLAY AGAIN");
        drawString(winWidth / 2 - 130, winHeight / 2 - 110,
                   "Press ESC to EXIT");
    }

    glutSwapBuffers();
}

// ---------- Timer / update ----------
void updateTimer(int value) {
    // Move lane dashes (road scrolling)
    if (gameState == STATE_PLAYING) {
        laneOffset += roadScrollSpeed;
        float dashGap = 80.0f;
        if (laneOffset > dashGap) laneOffset -= dashGap;
    }

    // Move buildings downward
    if (gameState == STATE_PLAYING) {
        for (size_t i = 0; i < buildings.size(); ++i) {
            buildings[i].y -= roadScrollSpeed * 0.85f;
            if (buildings[i].y + buildings[i].h < -40) {
                buildings[i].h = frand(130.0f, 220.0f);
                buildings[i].y = winHeight + frand(40.0f, 200.0f);
            }
        }
    }

    // Smooth car movement
    if (gameState == STATE_PLAYING) {
        float roadX  = winWidth * 0.25f;
        float roadW  = winWidth * 0.50f;

        if (keyMoveLeft && !keyMoveRight) {
            carX -= carSpeed;
        } else if (keyMoveRight && !keyMoveLeft) {
            carX += carSpeed;
        }

        // clamp inside road
        if (carX < roadX + 10) carX = roadX + 10;
        if (carX + carW > roadX + roadW - 10)
            carX = roadX + roadW - 10 - carW;
    }

    // Tilt target based on movement
    if (keyMoveLeft && !keyMoveRight) {
        carTiltTarget = 15.0f;     // slight left tilt (top view)
    } else if (keyMoveRight && !keyMoveLeft) {
        carTiltTarget = -15.0f;    // slight right tilt
    } else {
        carTiltTarget = 0.0f;
    }

    // Smooth interpolation of tilt
    float tiltSpeed = 2.0f;
    if (carTiltAngle < carTiltTarget) {
        carTiltAngle += tiltSpeed;
        if (carTiltAngle > carTiltTarget) carTiltAngle = carTiltTarget;
    } else if (carTiltAngle > carTiltTarget) {
        carTiltAngle -= tiltSpeed;
        if (carTiltAngle < carTiltTarget) carTiltAngle = carTiltTarget;
    }

    if (gameState == STATE_PLAYING) {
        frameCount++;

        // Increase difficulty slowly (more traffic)
        if (frameCount % (60 * 6) == 0 && enemySpawnInterval > enemySpawnMin) {
            enemySpawnInterval -= 2;
        }

        // Spawn enemies
        enemySpawnCounter++;
        if (enemySpawnCounter >= enemySpawnInterval) {
            spawnEnemyCar();
            enemySpawnCounter = 0;
        }

        // Move enemies (down + optional side move)
        float roadX  = winWidth * 0.25f;
        float roadW  = winWidth * 0.50f;
        float leftBound  = roadX + 10.0f;
        float rightBound = roadX + roadW - 10.0f;

        for (size_t i = 0; i < enemies.size(); ++i) {
            if (!enemies[i].active) continue;

            // vertical
            enemies[i].y -= enemies[i].speed;

            // side movement
            if (enemies[i].canSideMove) {
                enemies[i].sideChangeTimer -= 1.0f;
                if (enemies[i].sideChangeTimer <= 0.0f) {
                    // kichu time e thakbe stable, kichu time zig-zag
                    int r = rand() % 3;
                    if (r == 0) enemies[i].sideDir = 0;
                    else enemies[i].sideDir = (rand() % 2 == 0 ? -1 : 1);
                    enemies[i].sideChangeTimer = (float)(rand() % 70 + 30);
                }

                enemies[i].x += enemies[i].sideDir * enemies[i].sideSpeed;

                // boundary te gele bounce back
                if (enemies[i].x < leftBound) {
                    enemies[i].x = leftBound;
                    enemies[i].sideDir *= -1;
                }
                if (enemies[i].x + enemies[i].w > rightBound) {
                    enemies[i].x = rightBound - enemies[i].w;
                    enemies[i].sideDir *= -1;
                }
            }

            // Check if main car already overtook (crossed) this car
            if (!enemies[i].scored &&
                enemies[i].y + enemies[i].h < carY) {
                score += 10;          // MAIN CAR CROSSED -> +10
                enemies[i].scored = true;
            }

            // Remove if completely out
            if (enemies[i].y + enemies[i].h < -50) {
                enemies[i].active = false;
            }
        }

        // Collision: player vs enemy cars
        for (size_t i = 0; i < enemies.size(); ++i) {
            if (!enemies[i].active) continue;
            if (rectIntersect(carX, carY, carW, carH,
                              enemies[i].x, enemies[i].y, enemies[i].w, enemies[i].h)) {
                enemies[i].active = false;
                lives--;
                if (lives <= 0) {
                    if (score > bestScore) bestScore = score;
                    gameState = STATE_GAMEOVER;
                }
            }
        }
    }

    glutPostRedisplay();
    glutTimerFunc(16, updateTimer, 0); // ~60 FPS
}

// ---------- Keyboard (normal keys) ----------
void keyboard(unsigned char key, int x, int y) {
    if (key == 27) { // ESC
        exit(0);
    }

    if (gameState == STATE_MENU) {
        if (key == 13) { // ENTER
            resetGame();
            gameState = STATE_PLAYING;
        }
    }
    else if (gameState == STATE_PLAYING) {
        // A / D movement (hold)
        if (key == 'a' || key == 'A') {
            keyMoveLeft = true;
        }
        if (key == 'd' || key == 'D') {
            keyMoveRight = true;
        }
        // Space free ache � pore horn/nitro add korte parbo
    }
    else if (gameState == STATE_GAMEOVER) {
        if (key == 13) { // ENTER -> restart
            resetGame();
            gameState = STATE_PLAYING;
        }
    }

    glutPostRedisplay();
}

// ---------- Keyboard key release ----------
void keyboardUp(unsigned char key, int x, int y) {
    if (key == 'a' || key == 'A') keyMoveLeft  = false;
    if (key == 'd' || key == 'D') keyMoveRight = false;
}

// ---------- Special keys (LEFT / RIGHT) ----------
void specialKeys(int key, int x, int y) {
    if (gameState != STATE_PLAYING) return;

    if (key == GLUT_KEY_LEFT)  keyMoveLeft  = true;
    if (key == GLUT_KEY_RIGHT) keyMoveRight = true;

    glutPostRedisplay();
}

// ---------- Special keys release ----------
void specialKeysUp(int key, int x, int y) {
    if (key == GLUT_KEY_LEFT)  keyMoveLeft  = false;
    if (key == GLUT_KEY_RIGHT) keyMoveRight = false;
}

// ---------- Reshape ----------
void reshape(int w, int h) {
    winWidth  = w;
    winHeight = h;
    glViewport(0, 0, w, h);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, w, 0, h);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    // window size change hole buildings abar adjust
    initBuildings();
}

// ---------- Init OpenGL ----------
void initGL() {
    glClearColor(0.02f, 0.02f, 0.08f, 1.0f);

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, winWidth, 0, winHeight);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glShadeModel(GL_SMOOTH);
    glEnable(GL_LINE_SMOOTH);
    glHint(GL_LINE_SMOOTH_HINT, GL_NICEST);

    srand((unsigned int)time(0));

    carX = winWidth / 2.0f - carW / 2.0f;

    initBuildings();
}

// ---------- main ----------
int main(int argc, char **argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowSize(winWidth, winHeight);
    glutCreateWindow("Highway Car Racing Game - Hard Mode");

    initGL();

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);
    glutKeyboardUpFunc(keyboardUp);
    glutSpecialFunc(specialKeys);
    glutSpecialUpFunc(specialKeysUp);
    glutTimerFunc(16, updateTimer, 0);

    glutMainLoop();
    return 0;
}
